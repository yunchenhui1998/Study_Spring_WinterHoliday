package com.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sp.Student;

public class Main {

	public static void main(String[] args) {
		ApplicationContext context =
				new ClassPathXmlApplicationContext("ApplicationContext.xml");

		Student stu=(Student)context.getBean("stu");
		System.out.println(stu);
		System.out.println(stu.getName()+"\t"+stu.getAge()+"\t"+stu.getTea().getName());
	}

}
