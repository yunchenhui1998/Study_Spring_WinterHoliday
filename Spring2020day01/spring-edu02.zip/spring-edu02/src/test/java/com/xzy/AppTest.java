package com.xzy;

import static org.junit.Assert.assertEquals;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"/ApplicationContext.xml"})
public class AppTest 
{
	@Autowired
	Student stu;
	
	@Test
     public void test1()
     {
		System.out.println(stu.getName()+"\t"+stu.getAge()+"\t"+stu.getTea().getName());
       assertEquals("老李", stu.getTea().getName());
     }
}
